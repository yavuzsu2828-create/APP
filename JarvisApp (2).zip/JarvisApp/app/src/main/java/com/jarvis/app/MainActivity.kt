package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity() {
    lateinit var web: WebView
    var tts: TextToSpeech? = null
    var sr: SpeechRecognizer? = null
    var listening = false
    var talking = false
    val ui = Handler(Looper.getMainLooper())

    fun key(): String = getSharedPreferences("j", 0).getString("k", "") ?: ""

    fun askKey() {
        val et = android.widget.EditText(this)
        et.hint = "sk-ant-..."
        android.app.AlertDialog.Builder(this).setTitle("Anthropic API anahtarı").setView(et)
            .setPositiveButton("Kaydet") { _, _ ->
                getSharedPreferences("j", 0).edit().putString("k", et.text.toString().trim()).apply()
            }
            .setNegativeButton("Şimdi değil", null).show()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        tts = TextToSpeech(this) { tts?.language = Locale("tr", "TR") }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { js("onSpeakStart()") }
            override fun onDone(id: String?) {
                talking = false; js("onSpeakEnd()")
                if (listening) ui.postDelayed({ startListen() }, 300)
            }
            @Deprecated("") override fun onError(id: String?) { talking = false; js("onSpeakEnd()") }
        })
        web.loadUrl("file:///android_asset/index.html")
        if (key().isEmpty()) askKey()
    }

    fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    fun startListen() {
        if (talking || !listening) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr!!.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t != null) js("handle(${JSONObject.quote(t)})")
                    if (listening && !talking) ui.postDelayed({ startListen() }, 300)
                }
                override fun onError(e: Int) { if (listening && !talking) ui.postDelayed({ startListen() }, 500) }
                override fun onRmsChanged(v: Float) { js("window.extLvl=${v.coerceIn(0f, 10f) / 10f}") }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        sr!!.startListening(i)
    }

    inner class Bridge {
        @JavascriptInterface fun speak(t: String) = runOnUiThread {
            talking = true; sr?.cancel()
            tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
        }
        @JavascriptInterface fun listen(on: Boolean) = runOnUiThread {
            listening = on
            if (on) startListen() else sr?.cancel()
        }
        @JavascriptInterface fun battery(): Int =
            (getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        @JavascriptInterface fun location(): String {
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return ""
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val l = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.firstOrNull() ?: return ""
            return "${l.latitude},${l.longitude}"
        }
        @JavascriptInterface fun whatsapp(num: String, msg: String) {
            val n = num.filter { it.isDigit() }
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=${Uri.encode(msg)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun openApp(name: String): Boolean {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val hit = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name.lowercase()) } ?: return false
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
        }
        @JavascriptInterface fun changeKey() = runOnUiThread { askKey() }
        @JavascriptInterface fun ask(q: String) {
            if (key().isEmpty()) { js("onAnswer('Önce API anahtarını gir. Anahtar değiştir de.')"); return }
            Thread {
                val out = try {
                    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"; c.doOutput = true
                    c.setRequestProperty("x-api-key", key())
                    c.setRequestProperty("anthropic-version", "2023-06-01")
                    c.setRequestProperty("content-type", "application/json")
                    val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 300)
                        .put("system", "Sen Jarvis'sin. Türkçe, kısa ve net cevap ver.")
                        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    val r = (if (c.responseCode < 300) c.inputStream else c.errorStream).bufferedReader().readText()
                    JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
                } catch (e: Exception) { "Bağlantı hatası. API anahtarını kontrol et." }
                js("onAnswer(${JSONObject.quote(out)})")
            }.start()
        }
    }
}
